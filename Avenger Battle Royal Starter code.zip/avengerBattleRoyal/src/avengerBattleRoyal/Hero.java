package avengerBattleRoyal;


public abstract class Hero {
	
	public abstract  int baseAttack();
	public abstract void printHealth();
	
}
