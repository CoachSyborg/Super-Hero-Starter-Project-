package avengerBattleRoyal;

import java.util.Random;

public class WarMachine extends Hero{

	String name = "War-Machine";
	int health = 10000;
	
	@Override
	public int baseAttack() {
		//method to embody rail gun
		Random rng = new Random();
		int attackPower = rng.nextInt((10) + 1);
		System.out.println("War-Machine shot his rail gun for " 
		+ attackPower + " damage.");
		return attackPower;
	}

	@Override
	public void printHealth() {
		System.out.println("War-Machine's health is " + health);

	}

}
