package avengerBattleRoyal;

import java.util.Random;

public class IronMan extends Hero{
	//IronMans attributes 
	String name = "Iron-Man";
	int health = 10000;
	
	@Override
	public int baseAttack() {
		//method to embody repulser beam
		Random rng = new Random();
		int damage = rng.nextInt((1000) + 1);
		System.out.println("Iron-Man shot his repulser cannon for " 
		+ damage + " damage. ");
		return damage;
	}

	@Override
	public void printHealth() {
		System.out.println("Iron-Man's health is " + health);
	}
	
}
