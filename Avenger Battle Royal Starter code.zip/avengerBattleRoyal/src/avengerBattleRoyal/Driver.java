package avengerBattleRoyal;

public class Driver {

	public static void main(String[] args) {
		IronMan ironMan = new IronMan();
		WarMachine warMachine = new WarMachine();
		ironMan.baseAttack();
		warMachine.baseAttack();
		
		while(warMachine.health > 0 && ironMan.health > 0)
		{
			int ironManAttack = ironMan.baseAttack();
			int warMachineAttack = warMachine.baseAttack();
			ironMan.health = ironMan.health - warMachineAttack;
			warMachine.health = warMachine.health  - ironManAttack;
			ironMan.printHealth();
			warMachine.printHealth();
		}
		if(warMachine.health <= 0)
		{
			System.out.println("Iron-Man Won!!!!!!");
		}else {
			System.out.println("War-Machine Won!!!!");
		}
		
	}

}
